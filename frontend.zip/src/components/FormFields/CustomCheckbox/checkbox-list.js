import React, { Component } from 'react'
import classNames from 'classnames';
import PropTypes from 'prop-types'
import _ from 'lodash';
import { FormControl, FormGroup, FormLabel, FormHelperText } from '@mui/material'
import { Field } from "formik";
import { CheckboxWithLabel } from "formik-mui";
// *** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import withStyles from 'react-jss'


class CustomCheckboxList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            fieldArrayValues: [],
            error: false,
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            fieldArrayValues: props.fieldArrayValues,
            error: props.error
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        const isEqual = _(nextProps.fieldArrayValues).differenceWith(this.state.fieldArrayValues, _.isEqual).isEmpty();
        if (nextProps.error !== this.state.error || !isEqual)
            return true
        else return false
    }

    render() {
        const { formLabelText, helperText, direction, error, disabled, fullWidth, margin, classes, checkList } = this.props
        // console.log("=================================================");
        // console.log(`%c --- Render Custom Checkbox List`, "color: #118cc4");
        // console.log("=================================================");

        return (
            <FormControl
                component="fieldset"
                variant="standard"
                error={error}
                disabled={disabled}
                fullWidth={fullWidth}
                margin={margin}
            >
                <FormLabel
                    component="legend"
                    classes={{
                        error: classes.themeColorError,
                        focused: classes.formLabelFocused
                    }}
                >
                    {formLabelText}
                </FormLabel>
                <FormGroup row={direction === "row"}>
                    {checkList.map(({ id, name, labelText, value, ...props }) => (
                        <Field
                            key={`checkbox-field-${id}`}
                            type="checkbox"
                            name={name}
                            disabled={disabled}
                            value={value}
                            component={CheckboxWithLabel}
                            Label={{
                                label: labelText,
                                classes: {
                                    root: classNames({ [classes.themeColorError]: error }),
                                    error: classes.themeColorError
                                }
                            }}
                            classes={{
                                root: classNames({ [classes.themeColorError]: error }),
                                colorPrimary: classes.themeColorPrimary,
                                error: classes.themeColorError
                            }}
                        />
                    ))}
                </FormGroup>
                {helperText && (
                    <FormHelperText
                        classes={{
                            root: classes.helperText,
                            error: classes.themeColorError
                        }}
                    >
                        {helperText}
                    </FormHelperText>
                )}
            </FormControl>
        )
    }
}

CustomCheckboxList.defaultProps = {
    direction: "row"
}

CustomCheckboxList.propTypes = {
    formLabelText: PropTypes.string.isRequired,
    helperText: PropTypes.string,
    direction: PropTypes.oneOf(["row", "column"]),
    disabled: PropTypes.bool,
    error: PropTypes.bool
}


export default withStyles(commonStyles)(CustomCheckboxList)