import 'date-fns';
import {memo, useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames';
import { TextField, FormHelperText } from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
//*** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { MuiDatePickerStyles, defaultMaterialThemeStyles } from 'assets/styles/components/FormFields/datepicker.styles'
import { createUseStyles, useTheme } from 'react-jss';
const useStyles = createUseStyles(MuiDatePickerStyles)
const useCommonStyles = createUseStyles(commonStyles)


function Datepicker({ label, value, textfieldVariant = "standard", format, fullWidth, disabled, onDateChange, startAdornment, extraThemeComponents, withoutDateValidation, trackValueChanges }) {

    const [selectedDate, setSelectedDate] = useState(new Date());
    const [helperText, setHelperText] = useState("")
    const [invalidDate, setInvalidDate] = useState(false)
    const classes = useStyles()
    const commonClasses = useCommonStyles()
    const systemTheme = useTheme()
    const theme = createTheme({
        palette: {
            ...defaultMaterialThemeStyles(systemTheme).palette
        },
        components: {
            ...defaultMaterialThemeStyles(systemTheme).components,
            ...extraThemeComponents
        }
    });


    useEffect(() => {
        if(trackValueChanges){
            const date = new Date(value)
            if (date !== "Invalid Date" && !isNaN(date)){
                setSelectedDate(value)
                setInvalidDate(false)
            }
        }
    }, [value, trackValueChanges])


    const handleDateChange = value => {
        if (withoutDateValidation) {
            setSelectedDate(value)
            onDateChange(value)
        }
        else {
            if (String(value) === "Invalid Date" || value === null) {
                setHelperText("Invalid Date")
                setInvalidDate(true)
                // setSelectedDate(value)
                onDateChange(value, false)
            }
            else {
                const selectedYear = new Date(value).getFullYear()
                if (Number(selectedYear) < 1900 || Number(selectedYear) > 2099) {
                    setHelperText("Year must be between 1900 and 2099.")
                    setInvalidDate(true)
                    setSelectedDate(value)
                    onDateChange(value, false)
                }
                else {
                    setHelperText("")
                    setInvalidDate(false)
                    setSelectedDate(value)
                    onDateChange(value, true)
                }
            }
        }
    }

    return (
        <ThemeProvider theme={theme}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                    className={classNames(classes.root, {
                        [classes.labelError]: invalidDate
                    })}
                    label={label}
                    value={selectedDate}
                    inputFormat={format}
                    onChange={handleDateChange}
                    InputProps={{
                        startAdornment,
                        error: invalidDate,
                        disabled: disabled,
                        classes: {
                            root: classes.marginTop,
                            disabled: classes.disabled,
                            error: classes.error,
                            underline: classNames(classes.underline, {
                                [classes.underlineError]: invalidDate
                            })
                        }
                    }}
                    renderInput={props => (
                        <>
                            <TextField
                                fullWidth={fullWidth}
                                variant={textfieldVariant}
                                {...props}
                            />
                            {
                                invalidDate && (
                                    <FormHelperText classes={{ root: commonClasses.themeColorError }}>{helperText}</FormHelperText>
                                )
                            }
                        </>
                    )}
                />
            </LocalizationProvider>
        </ThemeProvider >
    )
}



Datepicker.defaultProps = {
    extraThemeComponents: {},
    format: "MM/dd/yyyy"
}

Datepicker.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.any,
    textfieldVariant: PropTypes.oneOf(["filled", "outlined", "standard"]),
    format: PropTypes.string,
    helperText: PropTypes.string,
    fullWidth: PropTypes.bool,
    disabled: PropTypes.bool,
    onDateChange: PropTypes.func
}

export default memo(Datepicker)