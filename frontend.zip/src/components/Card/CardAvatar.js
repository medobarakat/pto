import { memo } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/Card/cardAvatar.styles';
const useStyles = createUseStyles(styles)


function CardAvatar({ children, className, plain, profile }) {
    const classes = useStyles();
    const cardAvatarClasses = classNames({
        [classes.cardAvatar]: true,
        [classes.cardAvatarProfile]: profile,
        [classes.cardAvatarPlain]: plain,
        [className]: className !== undefined
    });
    
    return (
        <div className={cardAvatarClasses}>
            {children}
        </div>
    );
}

CardAvatar.propTypes = {
    children: PropTypes.node.isRequired,
    className: PropTypes.string,
    profile: PropTypes.bool,
    plain: PropTypes.bool
};

export default memo(CardAvatar)