import { memo } from 'react'

function FindProjectCard() {
  return (
    <div>
      
    </div>
  )
}

export default memo(FindProjectCard)
