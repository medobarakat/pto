import { memo, Fragment, useState, useEffect } from 'react'
import classNames from 'classnames'
import { Tooltip, Zoom } from '@mui/material';
import { motion } from 'framer-motion';
// *** styles ***
import { createUseStyles } from 'react-jss';
import { StatusCardsStyles } from 'assets/styles/views/logs.styles';
const useStyles = createUseStyles(StatusCardsStyles)



function motionProps(Idx, playAnimation) {
  if (Idx === 0) return {
    initial: { opacity: 0 },
    animate: { opacity: playAnimation ? 1 : 0 },
    transition: { type: "tween", duration: 1, ease: "easeInOut" }
  }
  else return {
    initial: { transform: `translateX(-${Idx * 100}%)` },
    animate: { transform: playAnimation ? "translateX(0px)" : `translateX(-${Idx * 100}%)` },
    transition: { type: "tween", duration: 1, ease: "easeInOut" }
  }
}


function StatusCards({ cards }) {
  const classes = useStyles();
  const [playAnimation, setPlayAnimation] = useState(false)


  useEffect(() => {
    const onPageLoad = () => setPlayAnimation(true)
    // Check if the page has already loaded
    if (document.readyState === 'complete') {
      onPageLoad();
    } else {
      window.addEventListener('load', onPageLoad);
      return () => window.removeEventListener('load', onPageLoad);
    }
  }, []);


  if (!(Array.isArray(cards) && cards?.length > 0))
    return <Fragment />
  else return (
    <div className={classes.statusCardsRoot}>
      {cards?.map(({ id, themeColor, innerText, descrption }, Idx) => (
        <motion.div
          key={`status-card-${id}`}
          className={classNames("info-card", themeColor)}
          {...motionProps(Idx, playAnimation)}
        >
          <Tooltip
            title={Boolean(innerText) ? innerText : "##"}
            TransitionComponent={Zoom}
          >
            <span>{Boolean(innerText) ? innerText : "##"}</span>
          </Tooltip>
          <p>{descrption}</p>
        </motion.div>
      ))}
    </div>
  )
}

export default memo(StatusCards)
