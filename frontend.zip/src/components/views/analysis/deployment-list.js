/**
 * TODO: List of Deployments that includes list of dynamic forms on each deployment tab
*/
import { memo, lazy, Suspense, useReducer, useCallback } from 'react'
import { useNavigate } from 'react-router-dom';
import { Accordion, AccordionDetails, AccordionSummary, Container, Typography, Tooltip, IconButton } from '@mui/material'
import axios from 'axios'
import _ from 'lodash'
// *** components ***
import LoadingProgress from 'components/loading-progress';
import DeploymentFormList from 'components/views/analysis/deployment-form-list';
import EmptyData from 'components/empty-data';
// *** redux ***
import { useSelector, useDispatch } from 'react-redux'
import { ChangeExpandedParentAccordion } from '@redux'
// *** Icons ***
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import TagIcon from '@mui/icons-material/Tag';
// *** styles ***
import { createUseStyles } from 'react-jss';
import { DeploymentListStyles } from 'assets/styles/views/analysis.styles';
import { useEffect } from 'react';
const useStyles = createUseStyles(DeploymentListStyles)
/**
 * Lazy Components
 */
const Button = lazy(() => import("@mui/material/Button"))
const Stack = lazy(() => import("@mui/material/Stack"))
const CustomDropdown = lazy(() => import('components/FormFields/CustomDropdown'))
const AddExceptionIcon = lazy(() => import('@mui/icons-material/BugReport'))


const dropdownProcessInitState = {
    loading: false,
    options: [],
    value: ""
}

const dropdownProcessReducer = (state, action) => {
    switch (action.type) {
        case "loading":
            return { ...state, loading: action.payload }
        case "options":
            return { ...state, options: action.payload }
        case "value":
            return { ...state, value: action.payload }
        default:
            return state
    }
}



function DeploymentList({ viewType, loading, deployments, processInfo, jobID, processInstanceId, projectNum, singleProcess }) {
    const dispatch = useDispatch()
    const { expandedParent, expandedChild } = useSelector(state => state.analysis)

    const classes = useStyles()
    const navigate = useNavigate()
    const [dropdownProcess, dispatchDropdownProcess] = useReducer(dropdownProcessReducer, dropdownProcessInitState)

    const handleDropdownProcessChange = useCallback((event, symbol) => {

        const __split = symbol.props.id.split("__TYPE__");
        const __jobID = __split[0]
        const __type = __split[1]
        const __value = symbol.props.value

        let urlSearchParams = {}
        if (__type === "projectNumber")
            _.assign(urlSearchParams, { jobID: __jobID, projectNumber: __value })
        else
            _.assign(urlSearchParams, { jobID: __jobID, processInstanceId: __value })

        dispatchDropdownProcess({ type: "value", payload: event.target.value })
        navigate({
            pathname: "/add-exception",
            hash: "#deployments",
            search: new URLSearchParams({ ...urlSearchParams }).toString()
        })
    }, [])

    const handleAccordionChange = useCallback((panel) => (event, isExpanded) => {
        dispatch(ChangeExpandedParentAccordion(isExpanded ? panel : false))
    }, [dispatch]);



    useEffect(() => {
        if (viewType === "analysis") {
            if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
                //?=================[ DEV ]========================                                
                dispatchDropdownProcess({ type: "loading", payload: true })
                setTimeout(() => {
                    dispatchDropdownProcess({ type: "loading", payload: false })
                    dispatchDropdownProcess({
                        type: "options",
                        payload: [
                            { id: `485541__TYPE__projectNumber`, value: "1E24A3EZ45", text: "PR12345 (848484848484848484848484848488484848484848484848484848484884848484848484848484848484848)" },
                            { id: `12669__TYPE__processInstanceId`, value: "9E66AQ1", text: "9E66AQ1(UUID2)" },
                            { id: `30113__TYPE__projectNumber`, value: "9E66AQ1", text: "PR12345 (84848484848499995214848)" },
                            { id: `65944__TYPE__projectNumber`, value: "9E66AQ1", text: "9E66AQ1(UUID4)" },
                            { id: `5962__TYPE__processInstanceId`, value: "AA15244A", text: "PR12345 (8484848484848484848)" },
                            { id: `596552__TYPE__projectNumber`, value: "EQT5211416", text: "NA(UUID5)" },
                        ]
                    })
                }, 1000);
            }
            else {
                //?=================[ PROD ]========================
                axios
                    .get(`/api/getAllProcessAnalysisInfoByJobId/${jobID}`)
                    .then(response => {
                        const options = response.data.map(({ id, jobId, processInstanceId, projectNumber, name }) => {
                            /**
                             * ? name alias to UUID
                             */
                            return {
                                id: `${jobId}__TYPE__${projectNumber ? "projectNumber" : "processInstanceId"}`,
                                value: projectNumber ? projectNumber : processInstanceId,
                                text: projectNumber ? `${projectNumber}(${name})` : `NA(${name})`
                            }
                        })

                        dispatchDropdownProcess({ type: "loading", payload: false })
                        dispatchDropdownProcess({ type: "options", payload: options })
                    })
                    .catch(error => {
                        dispatchDropdownProcess({ type: "loading", payload: false })
                        console.log(error)
                    })
            }
        }
    }, [viewType])


    useEffect(() => {
        if (!loading || !dropdownProcess.loading) {
            setTimeout(() => {
                const element = document.getElementById(`${expandedChild}-panel-header`);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                }
            }, 200)
        }
    }, [dropdownProcess.loading, loading])


    if (loading || dropdownProcess.loading) return (    
        <LoadingProgress />
    )
    else if (!Array.isArray(deployments) || deployments.length === 0) return (
        <EmptyData />
    )
    else return (
        <Container className='deployment-list-container' sx={{ my: 8 }}>
            <Suspense fallback={<></>}>
                {(viewType === "analysis" && !singleProcess) && (
                    <Stack
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        className="page-controls"
                    >
                        <div>
                            <Button
                                variant="contained"
                                className="add-exception-button"
                                onClick={() => navigate({
                                    pathname: '/add-exception',
                                    search: new URLSearchParams({ jobID }).toString(),
                                })}
                            >
                                <span>
                                    <AddExceptionIcon />
                                    Add Exception
                                </span>
                            </Button>
                        </div>
                        <div style={{ minWidth: 400 }}>
                            <CustomDropdown
                                id="dropdown-process"
                                variant="outlined"
                                label="Select Process"
                                value={dropdownProcess.value}
                                onChange={handleDropdownProcessChange}
                                items={dropdownProcess.options}
                                maxWidth={400}
                            />
                        </div>
                    </Stack>
                )}
            </Suspense>
            {/********************************************************/}
            {((viewType === "exception" || viewType === "add-exception") && !singleProcess) && (
                <Tooltip title={`${processInfo?.projectNumber ? processInfo?.projectNumber : "NA"} (${processInfo?.name})`}>
                    <div className={classes.InfoLabel}>
                        <Typography variant='h1' component="h1">
                            {processInfo?.projectNumber ? processInfo?.projectNumber : "NA"}&nbsp;{"("}{processInfo?.name}{")"}
                        </Typography>
                    </div>
                </Tooltip>
            )}
            {/********************************************************/}
            {deployments.map(({ DeploymentId, processVersion, processName, formData, ...props }) => (
                <Accordion
                    key={`deployment--${DeploymentId}`}
                    expanded={expandedParent === DeploymentId}
                    onChange={handleAccordionChange(DeploymentId)}
                    TransitionProps={{ unmountOnExit: true }}
                >
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        className={classes.accordionSummaryRoot}
                    >
                        <Typography>
                            <IconButton>
                                <TagIcon />
                            </IconButton>
                            <strong>{processName} ({processVersion})</strong>
                        </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <DeploymentFormList
                            key={`deployment-${DeploymentId}`}
                            jobID={jobID}
                            deploymentId={DeploymentId}
                            formData={formData}
                            viewType={viewType}
                            processInstanceId={processInstanceId}
                            projectNum={projectNum}
                        />
                    </AccordionDetails>
                </Accordion>
            ))}
        </Container>
    )
}


DeploymentList.defaultProps = {
    singleProcess: false,
    processInstanceId: "",
    projectNum: ""
}

export default memo(DeploymentList)
