import { memo, useState, useEffect } from 'react'
import { Snackbar, Typography, Button, IconButton, Slide } from '@mui/material';
import classNames from 'classnames'
// *** icons ***
import WifiIcon from '@mui/icons-material/Wifi';
import WifiOffIcon from '@mui/icons-material/WifiOff';
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import styles from 'assets/styles/components/snackbarConnection.styles'
import { createUseStyles } from 'react-jss'
const useStyles = createUseStyles(styles)

function SnackbarConnection({ isOnline }) {
  const classes = useStyles()
  const [open, setOpen] = useState(false)


  useEffect(() => {
    if (!isOnline && !navigator.onLine)
      setOpen(true)
  }, [isOnline])

  const handleCloseSnackbarConnection = () => setOpen(false)

  return (
    <Snackbar
      open={open}
      TransitionComponent={Slide}
      autoHideDuration={30000}
      onClose={handleCloseSnackbarConnection}
    >
      <div className={classNames(classes.snackbarConnection, {
        [classes.onlineConnection]: isOnline,
        [classes.offlineConnection]: !isOnline
      })}>
        {isOnline ? <WifiIcon /> : <WifiOffIcon />}
        <Typography>
          {isOnline ? "Your internet connection was restored." : "You are currently offline."}
        </Typography>
        {!isOnline && (
          <Button
            size='small'
            variant='text'
            className={classes.refreshBtn}
            onClick={() => window.location.reload()}
          >
            Refresh
          </Button>
        )}

        <IconButton
          size='small'
          className={classes.closeBtn}
          onClick={() => handleCloseSnackbarConnection()}
        >
          <CloseIcon />
        </IconButton>
      </div>
    </Snackbar>
  )
}

export default memo(SnackbarConnection)
