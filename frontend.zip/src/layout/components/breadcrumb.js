import React, { memo, useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom';
import { Breadcrumbs } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { pageRoutesJSON } from 'routes/protected.routes';
//*** styles ***
import { createUseStyles } from 'react-jss';
import { BreadcrumbStyles, MuiBreadcrumbTheme } from 'assets/styles/layout/mainLayout.styles';
const useStyles = createUseStyles(BreadcrumbStyles)
const theme = createTheme(MuiBreadcrumbTheme)


function Breadcrumb() {
    const classes = useStyles()
    const location = useLocation()
    const [breadcrumbList, setBreadcrumbList] = useState([])

    useEffect(() => {
        const result = [];
        const splitPath = location.pathname.split("/")
        splitPath.shift()
        splitPath.map((path, Idx) => {
            if (path !== "" && pageRoutesJSON[`/${path}`] !== undefined)
                result.push(pageRoutesJSON[`/${path}`])
        })

        if (location.pathname === "/")
            setBreadcrumbList([pageRoutesJSON["/"]])
        else if (result.length > 0)
            setBreadcrumbList([pageRoutesJSON["/"], ...result])
    }, [location])


    if (breadcrumbList.length === 0) return (
        <React.Fragment />
    )
    else return (
        <ThemeProvider theme={theme}>
            <Breadcrumbs
                aria-label="breadcrumb"
                className={classes.breadcrumbRoot}
                itemType=''
            >
                {breadcrumbList.map(({ id, title, path, icon }) => (
                    <span
                        key={`${id}-breadcrumb-item-inner`}
                        className="breadcrumb-item-inner"
                    >
                        {icon}
                        <span>{title}</span>
                    </span>
                ))}
            </Breadcrumbs>
        </ThemeProvider >
    )
}

export default memo(Breadcrumb)
