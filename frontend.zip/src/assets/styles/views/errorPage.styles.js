const ErrorPageStyles = theme => ({
    root: {
        fontFamily: "-apple-system, BlinkMacSystemFont, Roboto, Segoe UI, Fira Sans, Avenir, Helvetica Neue, Lucida Grande, sans-serif", 
        height: "calc(100vh - 64px)", 
        textAlign: "center", 
        display: "flex", 
        flexDirection: "column", 
        alignItems: "center", 
        justifyContent: "center",
        "& > div": {
            "& > h1": {
                display: "inline-block", 
                margin: "0 20px 0 0", 
                padding: "10px 23px 10px 0", 
                fontSize: 24, 
                fontWeight: 500, 
                verticalAlign: "top", 
                borderRight: "1px solid rgba(0, 0, 0, .3)"
            },
            "& > div": {
                display: "inline-block",
                textAlign: "left",
                lineHeight: "49px",
                height: 49,
                verticalAlign: "middle",
                "& h2": {
                    fontSize: 14,
                    fontWeight: "normal",
                    lineHeight: "inherit",
                    margin: 0,
                    padding: 0
                }
            }
        }
    }
})


export default ErrorPageStyles