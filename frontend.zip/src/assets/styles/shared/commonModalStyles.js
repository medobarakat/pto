const commonModalRootStyles = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
}

const commonModalBoxStyles = (theme, topSectionMarginBottom) => ({
    maxWidth: 500,
    width: "100%",
    padding: 20,
    borderRadius: 6,
    backgroundColor: theme.colors.white,
    outline: "unset",
    "& .modal-title": {
        fontSize: 24,
        fontWeight: 600
    },
    "& .top-section": {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: topSectionMarginBottom ? topSectionMarginBottom : 20,
        "& button": {
            background: "#e8e8e8"
        }
    },
    "& .alert-section": {
        marginBottom: 15
    },
})

export {
    commonModalRootStyles,
    commonModalBoxStyles
}
