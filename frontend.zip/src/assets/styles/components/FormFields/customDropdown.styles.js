import { transparentize } from 'polished'


const CustomDropdownStyles = theme => ({
    formControl: {
        "& > div:before": {
            borderBottomColor: `${theme.colors.gray[4]}!important`,
            borderBottomWidth: "1px !important"
        },
        "& > div:after": {
            borderBottomColor: `${theme.colors.primary[0]}!important`
        }
    },
    standardSelect: {
        margin: "12px 0 0",
        fontSize: ".75rem",
        fontWeight: "400",
        lineHeight: "1.42857",
        letterSpacing: 0,
        textTransform: "uppercase",
        textDecoration: "none",
    },
    select: {
        color: theme.colors.gray[2],
        // margin: "12px 0 0",
        // fontSize: ".75rem",
        // fontWeight: "400",
        // lineHeight: "1.42857",
        // letterSpacing: 0,
        // textTransform: "uppercase",
        // textDecoration: "none",
        "&:focus": {
            backgroundColor: "transparent !important"
        }
    },
    selectMenuItem: {
        clear: "both",
        color: theme.colors.gray[8],
        margin: "0 5px",
        display: "block",
        padding: "10px 20px",
        fontSize: 13,
        transition: "all 150ms linear",
        fontWeight: 400,
        lineHeight: 2,
        whiteSpace: "nowrap",
        borderRadius: 2,
        paddingRight: 30,
        "&:hover": {
            color: theme.colors.white,
            backgroundColor: `${theme.colors.primary[0]}!important`,
        }
    }
})


const ThemeOverrides = theme => ({
    components: {
        MuiInputLabel: {
            styleOverrides: {
                outlined: {
                    "&.Mui-focused": {
                        color: theme.colors.primary[0],                            
                    },
                    "&.Mui-shrink": {
                        color: theme.colors.primary[0]
                    }
                },
            }
        },
        MuiSelect: {
            styleOverrides: {
                select: {
                    paddingBottom: 14,
                    "& + input + svg": {
                        transition: "all 200ms linear"
                    },
                    "&:focus": {
                        backgroundColor: "transparent",
                    }
                },
                outlined: {
                    "&:hover ~ fieldset": {
                        borderColor: theme.colors.primary[0]
                    },
                    "&:focus ~ fieldset": {
                        borderColor: theme.colors.primary[0]
                    },
                },
                iconOpen: {
                    "& ~ fieldset": {
                        borderColor: transparentize(0.25, theme.colors.primary[0]) + "!important"
                    }
                }
            }
        },
        MuiPopover: {
            styleOverrides: {
                root: {
                    "& > div + div": {
                        maxHeight: "266px !important",
                        "&::-webkit-scrollbar-track": {
                            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, 0.3)",
                            "borderRadius": "60px",
                            "backgroundColor": "#F5F5F5"
                        },
                        "&::-webkit-scrollbar": {
                            "width": "6px",
                            "maxHeight": "6px",
                            "backgroundColor": "#F5F5F5"
                        },
                        "&::-webkit-scrollbar-thumb": {
                            "borderRadius": "60px",
                            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, .1)",
                            "backgroundColor": "rgba(0, 0, 0, 0.3)"
                        }
                    }
                }
            }
        },
        MuiMenuItem: {
            styleOverrides: {
                root: {
                    "&.Mui-selected": {
                        color: theme.colors.white,
                        backgroundColor: `${theme.colors.primary[0]}!important`,
                        fontWeight: "bold"
                    }
                }
            }
        },
    }
})


export {
    CustomDropdownStyles,
    ThemeOverrides
}