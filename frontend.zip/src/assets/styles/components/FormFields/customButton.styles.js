

import { transparentize } from 'polished'

const CustomButtonStyles = theme => ({
    textPrimary: {
        color: theme.colors.primary[0] + "!important"
    },
    textSuccess: {
        color: theme.colors.success[0] + "!important"
    },
    textError: {
        color: theme.colors.danger[0] + "!important"
    },
    textInfo: {
        color: theme.colors.info[0] + "!important"
    },
    textWarning: {
        color: theme.colors.warning[0] + "!important"
    },
    outlinedPrimary: {
        color: theme.colors.primary[0] + "!important",
        borderColor: transparentize(0.5, theme.colors.primary[0]) + "!important",
        "&:hover": {
            border: `1px solid ${theme.colors.primary[0]}!important`,
        }
    },
    outlinedSecondary: {
    },
    outlinedSuccess: {
        color: theme.colors.success[0] + "!important",
        borderColor: transparentize(0.5, theme.colors.success[0]) + "!important",
        "&:hover": {
            border: `1px solid ${theme.colors.success[0]}!important`,
        }
    },
    outlinedError: {
        color: theme.colors.danger[0] + "!important",
        borderColor: transparentize(0.5, theme.colors.danger[0]) + "!important",
        "&:hover": {
            border: `1px solid ${theme.colors.danger[0]}!important`,
        }
    },
    outlinedInfo: {
        color: theme.colors.info[0] + "!important",
        borderColor: transparentize(0.5, theme.colors.info[0]) + "!important",
        "&:hover": {
            border: `1px solid ${theme.colors.info[0]}!important`,
        }
    },
    outlinedWarning: {
        color: theme.colors.warning[0] + "!important",
        borderColor: transparentize(0.5, theme.colors.warning[0]) + "!important",
        "&:hover": {
            border: `1px solid ${theme.colors.warning[0]}!important`,
        }
    },
    containedPrimary: {
        backgroundColor: theme.colors.primary[0] + "!important"
    },
    containedSuccess: {
        backgroundColor: theme.colors.success[0] + "!important"
    },
    containedInfo: {
        backgroundColor: theme.colors.info[0] + "!important"
    },
    containedError: {
        backgroundColor: theme.colors.danger[0] + "!important"
    },
    containedWarning: {
        backgroundColor: theme.colors.warning[0] + "!important"
    },
    disabled: { // only when color is "primary" and variant is "contained"
        color: "rgba(255, 255, 255, 0.5) !important"
    }
})


const InteractiveButtonStyles = theme => ({
    wrapper: {
        position: 'relative',
        display: "inline-block"
    },
    fabProgress: {
        position: 'absolute',
        top: -6,
        left: -6,
        zIndex: 1,
    },
    buttonProgress: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        marginTop: -12,
        marginLeft: -12,
    }
})

export { InteractiveButtonStyles }
export default CustomButtonStyles