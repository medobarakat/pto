import { transparentize } from 'polished'

const SnackbarConnectionStyles = theme => ({
    snackbarConnection: {
        borderRadius: 6,
        backgroundColor: "#333",
        padding: "15px 10px 15px 15px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        "& > svg": {
            marginRight: 10
        },
        "& p": {
            color: theme.colors.white
        },
    },
    onlineConnection: {
        "& > svg": {
            color: "#44b700",
        },
    },
    offlineConnection: {
        "& > svg": {
            color: "#888",
        }
    },
    refreshBtn: {
        marginLeft: 10,
        backgroundColor: transparentize(0.8, theme.colors.white),
        color: theme.colors.white,
        textTransform: "capitalize",
        "&:hover": {
            backgroundColor: transparentize(0.4, theme.colors.white),
            color: theme.colors.black,
        }
    },
    closeBtn: {
        backgroundColor: transparentize(0.6, theme.colors.black),
        color: theme.colors.white,
        "&:hover": {
            backgroundColor: theme.colors.black,
            color: theme.colors.white,
        },
        marginLeft: 10,
        padding: 2,
        "& svg": {
            fontSize: 18
        }
    }
})


export default SnackbarConnectionStyles